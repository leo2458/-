#Создай собственный Шутер!
from random import *
from pygame import *
mixer.init()
mixer.music.load('space.ogg')
mixer.music.play()
#создай окно игры
window = display.set_mode((700, 500))
display.set_caption('Бой с пришельцами злыми очень бууууу и вообще они страшные и т.дф')
background = transform.scale(image.load('galaxy.jpg'), (700, 500))
# Класс спрайта
class GameSprite(sprite.Sprite):
    def __init__(self, player_image, player_x, player_y, player_speed, heidht, widht):
        super().__init__()
        self.image = transform.scale(image.load(player_image), (widht, heidht))
        self.speed = player_speed
        self.rect = self.image.get_rect()     
        self.rect.x = player_x
        self.rect.y = player_y
    def reset(self):
        window.blit(self.image, (self.rect.x, self.rect.y))
class PlayerHero(GameSprite):
    def update(self):
        keys_pressed = key.get_pressed()

        if keys_pressed[K_a] and self.rect.x > 5:
            self.rect.x -= self.speed
        if keys_pressed[K_d] and self.rect.x < 595:
            self.rect.x += self.speed
    def Fire(self):
        bull = Bullets('bullet.png', self.rect.centerx, self.rect.y, 30, 20, 15)
        bullets.add(bull)
rocket = PlayerHero('rocket.png', 650, 410, 11, 70,90)
# КИБОРГ УБИЙЦА :()
lost = 0
class Enemy(GameSprite):
    def update(self):
        global lost
        self.rect.y += self.speed
        if self.rect.y >= 500:
            self.rect.y = -50
            self.rect.x = randint (100, 600)
            lost = lost + 1
# Пульки
class Bullets(GameSprite):
    def update(self):
        self.rect.y -= self.speed
        if self.rect.y < 0:
            self.kill()
bullets = sprite.Group()
# Фпс
clock = time.Clock()
# Монстры на короблях крутых и тд
ticktac = sprite.Group()
for i in range(5):
    monster = Enemy('ufo.png',randint(100, 600), -50, randint(2, 4), 60, 100)
    ticktac.add(monster)
# Убито зелнок

#задай фон сцены
killll = 0
game = True
kill = False
font.init()
textWIN = font.SysFont('arial', 70).render('Ты выиграл:)', True, (0,255,0))
textLOSER = font.SysFont('arial', 70).render('Ты ЛУЗЕР!!!!!', True, (204,0,0))
while game:
    for e in event.get():
        if e.type == QUIT:
            game = False
        elif e.type == KEYDOWN:
            if e.key == K_w:
                rocket.Fire()
    
    if not kill:
        window.blit(background,(0, 0))
        rocket.reset()
        rocket.update()
        ticktac.update()
        ticktac.draw(window)
        skip = font.SysFont('arial', 30).render('Пропущено:' + str(lost), True, (204,0,0))
        window.blit(skip, (50,50))
        bullets.update()
        bullets.draw(window)
        sprite_list = sprite.groupcollide( ticktac, bullets, True, True)
        for i in sprite_list:
            monster = Enemy('ufo.png',randint(100, 600), -50, randint(2, 4), 60, 100)
            ticktac.add(monster)
            killll += 1
        killl = font.SysFont('arial', 30).render('Убито:'+ str(killll), True, (0,255,0))
        window.blit(killl,(50, 70))
        if killll >= 20:
            window.blit(textWIN, (200, 200))
            kill = True
        if lost >= 10 or sprite.spritecollide(rocket, ticktac, False):
            window.blit(textLOSER, (200, 200))
            kill = True
    display.update()
    clock.tick(59)